package vn.daodong;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    private LinearLayout box;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad * 2, pad, pad * 2);
        scroll.addView(box);
        setContentView(scroll);

        Calendar c = Calendar.getInstance();
        int[] l = Lunar.fromSolar(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR));
        label("Đảo Động", 26);
        label("Hôm nay âm lịch: " + l[0] + "/" + l[1] + (l[3] == 1 ? " nhuận" : "") + " năm " + Lunar.yearName(l[2]), 16);

        label("Bước 1: thêm widget", 18);
        Button add = new Button(this);
        add.setText("Thêm widget ra màn hình chính");
        add.setAllCaps(false);
        add.setOnClickListener(v -> {
            AppWidgetManager mgr = getSystemService(AppWidgetManager.class);
            if (mgr.isRequestPinAppWidgetSupported())
                mgr.requestPinAppWidget(new ComponentName(this, LunarWidget.class), null, null);
            else Toast.makeText(this, "Hãy nhấn giữ màn hình chính > Widget > Đảo Động", Toast.LENGTH_LONG).show();
        });
        box.addView(add);

        label("Bước 2: cấp quyền để hiện thông báo và nhạc", 18);
        button("Bật quyền đọc thông báo", Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);

        label("Tùy chọn", 18);
        toggle("Hiện thông báo trên widget", "notify", true);
        toggle("Thông báo chỉ hiện logo app", "logoOnly", false);
        toggle("Hiện nhạc đang phát", "music", true);
    }

    @Override protected void onResume() {
        super.onResume();
        LunarWidget.refresh(this);
    }

    private void label(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, sp > 16 ? 36 : 8, 0, 8);
        box.addView(t);
    }

    private void button(String s, String action) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(v -> startActivity(new Intent(action)));
        box.addView(b);
    }

    private void toggle(String s, String key, boolean def) {
        SharedPreferences p = Prefs.of(this);
        Switch sw = new Switch(this);
        sw.setText(s);
        sw.setChecked(p.getBoolean(key, def));
        sw.setPadding(0, 16, 0, 16);
        sw.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean(key, on).apply();
            LunarWidget.refresh(this);
        });
        box.addView(sw);
    }
}
