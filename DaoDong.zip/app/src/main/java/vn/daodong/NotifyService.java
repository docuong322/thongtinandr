package vn.daodong;

import android.app.Notification;
import android.content.ComponentName;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.List;

public class NotifyService extends NotificationListenerService {
    static NotifyService instance;
    private MediaSessionManager sessions;
    private MediaController current;
    private final java.util.Map<MediaController, MediaController.Callback> watched = new java.util.HashMap<>();
    private final MediaSessionManager.OnActiveSessionsChangedListener onSessions = this::watch;

    /** Cập nhật widget mỗi phút và khi bật màn hình. */
    private final android.content.BroadcastReceiver clock = new android.content.BroadcastReceiver() {
        @Override public void onReceive(android.content.Context c, android.content.Intent i) { publish(); }
    };
    private boolean clockOn;

    @Override public void onListenerConnected() {
        instance = this;
        android.content.IntentFilter f = new android.content.IntentFilter(android.content.Intent.ACTION_TIME_TICK);
        f.addAction(android.content.Intent.ACTION_SCREEN_ON);
        if (!clockOn) { registerReceiver(clock, f); clockOn = true; }
        sessions = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        ComponentName me = new ComponentName(this, NotifyService.class);
        sessions.addOnActiveSessionsChangedListener(onSessions, me);
        watch(sessions.getActiveSessions(me));
        publish();
    }

    @Override public void onListenerDisconnected() {
        if (sessions != null) sessions.removeOnActiveSessionsChangedListener(onSessions);
        unwatch();
        if (clockOn) { unregisterReceiver(clock); clockOn = false; }
        instance = null;
        current = null;
        publish();
    }

    private void unwatch() {
        for (java.util.Map.Entry<MediaController, MediaController.Callback> e : watched.entrySet())
            e.getKey().unregisterCallback(e.getValue());
        watched.clear();
    }

    private void watch(List<MediaController> list) {
        unwatch();
        if (list != null) for (MediaController c : list) {
            MediaController.Callback cb = new MediaController.Callback() {
                @Override public void onPlaybackStateChanged(PlaybackState s) { pick(); }
                @Override public void onMetadataChanged(android.media.MediaMetadata m) { pick(); }
            };
            c.registerCallback(cb);
            watched.put(c, cb);
        }
        pick();
    }

    /** Ưu tiên trình phát đang chạy; nếu tạm dừng thì giữ trình phát gần nhất. */
    private void pick() {
        MediaController playing = null;
        for (MediaController c : watched.keySet()) if (isPlaying(c)) playing = c;
        if (playing != null) current = playing;
        else if (!watched.containsKey(current)) current = null;
        publish();
    }

    static boolean isPlaying(MediaController c) {
        PlaybackState s = c == null ? null : c.getPlaybackState();
        return s != null && s.getState() == PlaybackState.STATE_PLAYING;
    }

    MediaController media() { return current; }

    private void publish() { LunarWidget.refresh(this); }

    @Override public void onNotificationPosted(StatusBarNotification n) { publish(); }

    @Override public void onNotificationRemoved(StatusBarNotification n) { publish(); }

    /** Tối đa 3 thông báo mới nhất đang có trên máy. */
    java.util.List<StatusBarNotification> latest() {
        java.util.List<StatusBarNotification> out = new java.util.ArrayList<>();
        StatusBarNotification[] all;
        try { all = getActiveNotifications(); } catch (RuntimeException e) { return out; }
        if (all == null) return out;
        java.util.Arrays.sort(all, (a, b) -> Long.compare(b.getPostTime(), a.getPostTime()));
        for (StatusBarNotification n : all) {
            Notification x = n.getNotification();
            if (n.isOngoing() || n.getPackageName().equals(getPackageName())) continue;
            if ((x.flags & Notification.FLAG_GROUP_SUMMARY) != 0) continue;
            if (x.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) continue;
            if (x.extras.getCharSequence(Notification.EXTRA_TITLE) == null
                    && x.extras.getCharSequence(Notification.EXTRA_TEXT) == null) continue;
            out.add(n);
            if (out.size() == 3) break;
        }
        return out;
    }
}
