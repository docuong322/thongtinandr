package vn.daodong;

import android.app.Notification;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.List;

public class LunarWidget extends AppWidgetProvider {
    private static final String TOGGLE = "vn.daodong.TOGGLE", PREV = "vn.daodong.PREV",
            PLAY = "vn.daodong.PLAY", NEXT = "vn.daodong.NEXT";
    private static final int[] ROW = {R.id.n1, R.id.n2, R.id.n3};
    private static final int[] ICON = {R.id.i1, R.id.i2, R.id.i3};
    private static final int[] TEXT = {R.id.t1, R.id.t2, R.id.t3};

    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (TOGGLE.equals(a)) {
            SharedPreferences p = Prefs.of(c);
            p.edit().putBoolean("open", !p.getBoolean("open", false)).apply();
        }
        NotifyService s = NotifyService.instance;
        MediaController m = s == null ? null : s.media();
        if (m != null) {
            if (PREV.equals(a)) m.getTransportControls().skipToPrevious();
            if (NEXT.equals(a)) m.getTransportControls().skipToNext();
            if (PLAY.equals(a)) {
                if (NotifyService.isPlaying(m)) m.getTransportControls().pause();
                else m.getTransportControls().play();
            }
        }
        refresh(c);
    }

    static void refresh(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, LunarWidget.class));
        if (ids.length > 0) mgr.updateAppWidget(ids, build(c));
    }

    private static PendingIntent action(Context c, String a) {
        return PendingIntent.getBroadcast(c, 0, new Intent(c, LunarWidget.class).setAction(a),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        SharedPreferences p = Prefs.of(c);
        Calendar now = Calendar.getInstance();
        int d = now.get(Calendar.DAY_OF_MONTH), m = now.get(Calendar.MONTH) + 1, y = now.get(Calendar.YEAR);
        int[] l = Lunar.fromSolar(d, m, y);
        String hn = Lunar.hourName(now.get(Calendar.HOUR_OF_DAY), d, m, y);
        String dn = Lunar.dayName(d, m, y), mn = Lunar.monthName(l[1], l[2]);

        v.setTextViewText(R.id.date, Lunar.moon(l[0]) + " ÂL " + l[0] + "/" + l[1] + (l[3] == 1 ? " nhuận" : ""));
        v.setTextViewText(R.id.animals, "Giờ " + Lunar.animal(hn) + " Ngày " + Lunar.animal(dn) + " Tháng " + Lunar.animal(mn));
        v.setOnClickPendingIntent(R.id.header, action(c, TOGGLE));
        v.setOnClickPendingIntent(R.id.details, action(c, TOGGLE));

        boolean open = p.getBoolean("open", false);
        v.setViewVisibility(R.id.details, open ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.feed, open ? View.GONE : View.VISIBLE);
        if (open) {
            v.setTextViewText(R.id.details, "Giờ " + hn + "\nNgày " + dn + "\nTháng " + mn + "\nNăm " + Lunar.yearName(l[2])
                    + "\n🌿 Tiết " + Lunar.solarTerm(d, m, y) + "\n✨ Giờ hoàng đạo\n" + Lunar.goodHours(d, m, y));
            return v;
        }

        NotifyService s = NotifyService.instance;
        MediaController media = s != null && p.getBoolean("music", true) ? s.media() : null;
        v.setViewVisibility(R.id.music, media == null ? View.GONE : View.VISIBLE);
        if (media != null) {
            MediaMetadata meta = media.getMetadata();
            String title = meta == null ? null : meta.getString(MediaMetadata.METADATA_KEY_TITLE);
            v.setTextViewText(R.id.song, "♫ " + (title == null ? "Đang phát" : title));
            v.setTextViewText(R.id.play, NotifyService.isPlaying(media) ? "⏸" : "▶");
            v.setOnClickPendingIntent(R.id.prev, action(c, PREV));
            v.setOnClickPendingIntent(R.id.play, action(c, PLAY));
            v.setOnClickPendingIntent(R.id.next, action(c, NEXT));
        }

        List<StatusBarNotification> notes = s != null && p.getBoolean("notify", true) ? s.latest() : new java.util.ArrayList<>();
        boolean logoOnly = p.getBoolean("logoOnly", false);
        for (int i = 0; i < 3; i++) {
            boolean has = i < notes.size();
            v.setViewVisibility(ROW[i], has ? View.VISIBLE : View.GONE);
            if (!has) continue;
            StatusBarNotification n = notes.get(i);
            Notification x = n.getNotification();
            Bitmap icon = appIcon(c, n.getPackageName());
            if (icon != null) v.setImageViewBitmap(ICON[i], icon);
            CharSequence title = x.extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = x.extras.getCharSequence(Notification.EXTRA_TEXT);
            v.setViewVisibility(TEXT[i], logoOnly ? View.GONE : View.VISIBLE);
            v.setTextViewText(TEXT[i], (title == null ? "" : title) + (text == null ? "" : ": " + text));
            if (x.contentIntent != null) v.setOnClickPendingIntent(ROW[i], x.contentIntent);
        }
        // Chỉ hiện logo thì xếp ngang
        v.setInt(R.id.notes, "setOrientation", logoOnly ? 0 : 1);

        String enabled = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        boolean granted = enabled != null && enabled.contains(c.getPackageName() + "/");
        v.setViewVisibility(R.id.hint, granted ? View.GONE : View.VISIBLE);
        v.setOnClickPendingIntent(R.id.hint, PendingIntent.getActivity(c, 1,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        return v;
    }

    private static Bitmap appIcon(Context c, String pkg) {
        try {
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            Bitmap b = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, 72, 72);
            d.draw(new Canvas(b));
            return b;
        } catch (Exception e) {
            return null;
        }
    }
}
